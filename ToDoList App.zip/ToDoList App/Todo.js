let inputs = document.getElementById("inp");
let text = document.querySelector(".text");

function Add(){
    if(inputs.value == ""){
        alert('Please enter Task');
        }else {
            let newEle = document.createElement("ul");
            newEle.innerHTML=`${inputs.value} <i class="fa-solid fa-trash"></i>`;
            text.appendChild(newEle);
            inputs.value = "" ;
            newEle.querySelector("i").addEventListener("click",Delete) ;
            function Delete(){
                newEle.remove();
            }
}
}